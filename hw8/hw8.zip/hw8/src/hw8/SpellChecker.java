package hw8;

import java.io.Reader;

public class SpellChecker implements ISpellChecker {

	@Override
	public void ReadDictionary(Reader reader) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String[] CheckWord(String word) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static void main(String[] args)  // This is used for Part 2
	{
	}

}
