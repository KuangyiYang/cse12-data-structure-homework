package hw8;

import java.io.PrintStream;

public class HashTable implements IHashTable {

	@Override
	public boolean Insert(String value) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean Delete(String value) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean Lookup(String value) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void Print(PrintStream out) {
		// TODO Auto-generated method stub
		
	}

	public static void main(String[] args) // This is used only for Part 1
	{
	}
}
